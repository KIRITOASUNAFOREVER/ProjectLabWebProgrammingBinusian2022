<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cart extends Model
{

    protected $table='cart';
    protected $fillable=['id_user','id_sepatu','quantity'];
    public function user(){
        return $this->belongsTo('App\user','id_user','id');
    }
    public function sepatu(){
        return $this->belongsTo('App\sepatu','id_sepatu','id');
    }
}
