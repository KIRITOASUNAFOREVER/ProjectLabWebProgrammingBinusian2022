<?php

namespace App\Http\Controllers;

use App\cart;
use App\transaction;
use App\transaction_detail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class transactionController extends Controller
{
    function addTransaction(){
        $carts = cart::where('id_user',Auth::user()->id)->get();
        $transaction = new transaction();
        $transaction->id_user = Auth::user()->id;
        $transaction->save();
        foreach ($carts as $cart){
            $transaction_detail = new transaction_detail();
            $transaction_detail->id_sepatu = $cart->sepatu->id;
            $transaction_detail->id_transaksi = $transaction->id;
            $transaction_detail->quantity = $cart->quantity;
            $transaction_detail->save();
        }
        cart::where('id_user',Auth::user()->id)->delete();
        return redirect()->route('main');
    }
    function viewTransaction(){
        $transactions = transaction::where('id_user',Auth::user()->id)->get();
        $hargaTotal = [];
        foreach($transactions as $transaction){
            $total = 0;
            foreach($transaction->transaction_detail as $transaction_detail){
                $total = $total + ($transaction_detail->sepatu->price*$transaction_detail->quantity);
            }
            array_push($hargaTotal,$total);
        }
        return view('main_login.viewTransaction',['transactions'=>$transactions,'hargaTotal'=>$hargaTotal]);
    }
    function viewAllTransaction(){
        $transactions = transaction::all();
        $hargaTotal = [];
        foreach($transactions as $transaction){
            $total = 0;
            foreach($transaction->transaction_detail as $transaction_detail){
                $total = $total + ($transaction_detail->sepatu->price*$transaction_detail->quantity);
            }
            array_push($hargaTotal,$total);
        }
        return view('main_login.viewTransaction',['transactions'=>$transactions,'hargaTotal'=>$hargaTotal]);
    }
}
