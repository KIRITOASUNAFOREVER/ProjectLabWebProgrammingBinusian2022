<?php

namespace App\Http\Controllers;

use App\cart;
use App\sepatu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class cartController extends Controller
{
    function showViewCart(){
        $userId = Auth::user()->id;

        $cart = cart::where('id_user',$userId)->get();
        return view('main_login.viewCart',['carts'=>$cart]);
    }
    function showAddToCart($shoesId){
        $shoes = sepatu::where('id',$shoesId)->first();
        $cart  = cart::where('id_sepatu',$shoesId)->where('id_user',Auth::user()->id)->first();
        if($cart==null)
        {
            return view('main_login.addToCart',['shoe'=>$shoes,'error'=>'']);
        }
        else{
            return view('main_login.addToCart',['shoe'=>$shoes,'error'=>'shoes already in the cart please edit the shoes in the cart!']);
        }
    }
    function addToCart($shoesId, Request $request){
        $rule = [
            'quantity'=> 'integer|required|min:1'
        ];
        $attribute =[
            'quantity'=> 'Quantity'
        ];
        $message=[
            'required'=>':attribute is required',
            'integer'=>':attribute must be numeric',
            "min"=> ':attribute minimal must be 1'
        ];
        $this->validate($request,$rule,$message,$attribute);
        $cart = new Cart();
        $cart->id_user = Auth::user()->id;
        $cart->id_sepatu = $shoesId;
        $cart->quantity = $request->quantity;
        $cart->save();
        return redirect()->route('main')->with('Success','Success Add To Cart');
    }
    function showEditCart($shoesId){
        $cart = cart::where('id_user',Auth::user()->id)->where('id_sepatu',$shoesId)->first();

        return view('main_login.editCart',['cart'=>$cart]);
    }
    function updateCart(Request $request, $shoesId){
        $rule = [
            'quantity'=> 'integer|required|min:1'
        ];
        $attribute =[
            'quantity'=> 'Quantity'
        ];
        $message=[
            'required'=>':attribute is required',
            'integer'=>':attribute must be numeric',
            "min"=> ':attribute minimal must be 1'
        ];
        $this->validate($request,$rule,$message,$attribute);
        cart::where('id_user',Auth::user()->id)->where('id_sepatu',$shoesId)->update(array('quantity'=>$request->quantity));

        return redirect()->route('viewCart');
    }
    function deleteCart($shoesId){
        $cart=cart::where('id_user',Auth::user()->id)->where('id_sepatu',$shoesId);
        $cart->delete();
        return redirect()->route('viewCart');
    }
}
