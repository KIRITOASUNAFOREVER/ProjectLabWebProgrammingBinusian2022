<?php

namespace App\Http\Controllers;

use App\user;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Hash;

class userController extends Controller
{
    function registerUser(Request $request){
        $rule = [
            'username'=> 'required',
            'password'=> 'required|confirmed|min:3',
            'email'=> 'required|unique:user,email|email'
        ];
        $attribute = [
            'username'=>'Username',
            'password'=>'Password',
            'email'=>'Email'
        ];
        $message = [
            'required'=> ':attribute is required',
            'unique'=>':attribute is already used',
            'email'=>':attribute must be a proper email',
            'min'=>':attribute minimal length is :min',
            'confirmed'=>'Password and Confirm Password does not match'
        ];
        $this->validate($request,$rule,$message,$attribute);
        $username = $request->username;
        $email = $request->email;
        $password = $request->password;
        $x = new user();
        $x->username = $username;
        $password =Hash::make($password);
        $x->password = $password;
        $x->email    = $email;
        $x->role     = 'User';
        $x->save();
        return redirect()->route('login');
    }
    function loginUser(Request $request){
        $email=$request->email;
        $password=$request->password;
        $remember = $request->rememberme;

        if($remember == 'on'){
            if(Auth::attempt(['email' => $email, 'password' => $password],true)){
                $rememberMe = Auth::getRecallerName();
                Cookie::queue($rememberMe,Cookie::get($rememberMe),120);
                return redirect()->route('main');
            }
        }
        if(Auth::attempt(['email' => $email, 'password' => $password])){
            return redirect()->route('main');
        }
        else{
            return back()->with("error", "Email/password is Wrong");
        }
    }
    function logout(){
        Auth::logout();
        $cookie = Auth::getRecallerName();
        Cookie::queue(Cookie::forget($cookie));
        return redirect()->route('main');
    }

    function showAddShoes(){
        return view('admin_login.addShoes');
    }

}
