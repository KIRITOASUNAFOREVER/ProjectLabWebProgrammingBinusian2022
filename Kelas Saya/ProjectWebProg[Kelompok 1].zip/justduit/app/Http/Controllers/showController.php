<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class showController extends Controller
{
    function showLogin(){
        return view('login.login');
    }
    function showRegister(){
        return view('login.register');
    }
}
