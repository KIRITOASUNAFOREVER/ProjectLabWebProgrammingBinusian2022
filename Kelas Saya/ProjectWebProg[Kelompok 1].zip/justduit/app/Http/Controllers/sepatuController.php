<?php

namespace App\Http\Controllers;

use App\sepatu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class sepatuController extends Controller
{
    function insertShoes(Request $request){
        $rule = [
            'name'=> 'required',
            'description'=> 'required',
            'price'=> 'integer|required|min:100',
            'image'=> 'image|required'
        ];
        $attribute =[
            'name'=>'Name',
            'description'=>'Description',
            'price'=>'Price',
            'image'=>'Image',
        ];
        $message=[
            'required'=>':attribute is required',
            'integer'=>':attribute must be numeric',
            "image"=> ':attribute must be image'
        ];
        $this->validate($request,$rule,$message,$attribute);
        $name = $request->name;
        $description = $request->description;
        $price = $request->price;
        $image = '';
        if(empty($request->image)){
            $image=null;
        }
        else{
            $image = $request->file('image')->store('img','public');
        }
        $x = new sepatu();
        $x->name = $name;
        $x->description = $description;
        $x->image = $image;
        $x->price    = $price;
        $x->save();
        return redirect()->route('viewAddShoes')->with('success','Add Shoes Success');
    }
    function showMain(){
        $shoes = sepatu::paginate(6);
        return view('main.homepage',['shoes'=>$shoes]);
    }
    function showDetail($shoesId){
        $shoe = sepatu::where('id',$shoesId)->first();
        return view('main.shoeDetail',['shoe'=>$shoe]);
    }
    function updateShoes($shoesId){
        $shoe = sepatu::where('id',$shoesId)->first();
        return view('admin_login.shoesUpdate',['shoe'=>$shoe]);
    }
    function updateSuccess(Request $request,$id){

        $rule = [
            'name'=> 'required',
            'description'=> 'required',
            'price'=> 'integer|required|min:100',
            'image'=> 'image'
        ];
        $attribute =[
            'name'=>'Name',
            'description'=>'Description',
            'price'=>'Price',
            'image'=>'Image',
        ];
        $message=[
            'required'=>':attribute is required',
            'integer'=>':attribute must be numeric',
            "image"=> ':attribute must be image',
            'min'=> 'Minimal price is 100'
        ];
        $this->validate($request,$rule,$message,$attribute);
        $shoe = sepatu::where('id',$id)->first();
        $name = $request->name;
        $description = $request->description;
        $price = $request->price;
        $image = '';
        if(empty($request->image)){
            $image=$shoe->image;
        }
        else{
            $deleteImage = $shoe->image;
            Storage::delete($deleteImage);
            $image = $request->file('image')->store('img','public');

        }
        $shoe->name = $name;
        $shoe->description = $description;
        $shoe->image = $image;
        $shoe->price  = $price;
        $shoe->save();
        return redirect()->route('shoesDetail',['shoesId'=>$shoe->id])->with('successUpdate','Update success');
    }
    function search(Request $request){
        $sepatu = sepatu::where('name','like','%'.$request->search.'%')->paginate(6);
        return view('main.homepage',['shoes'=>$sepatu]);
    }
}
