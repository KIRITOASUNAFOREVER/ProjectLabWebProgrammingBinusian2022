<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transaction_detail extends Model
{

    protected $table='transaction_detail';
    protected $fillable=['id_transaksi','id_sepatu','quantity'];
    public function transaction(){
        return $this->belongsTo('App\transaction','id_transaksi','id');
    }
    public function sepatu(){
        return $this->belongsTo('App\sepatu','id_sepatu','id');
    }
}
