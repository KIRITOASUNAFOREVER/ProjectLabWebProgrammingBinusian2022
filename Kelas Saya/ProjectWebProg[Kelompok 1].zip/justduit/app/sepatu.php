<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sepatu extends Model
{
    protected $primarykey='id';
    protected $table='sepatu';
    protected $fillable=['name','description','price','image'];
    public function transactionDetail(){
        return $this->hasMany('App\transaction_detail','id_sepatu','id');
    }
    public function cart(){
        return $this->hasMany('App\cart','id_sepatu','id');
    }
}
