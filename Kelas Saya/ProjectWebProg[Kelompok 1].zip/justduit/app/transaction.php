<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transaction extends Model
{
    protected $primarykey='id';
    protected $table='transaction';
    protected $fillable=['id_user'];
    public function transaction_detail(){
        return $this->hasMany('App\transaction_detail','id_transaksi','id');
    }
    public function user(){
        return $this->belongsTo('App\user','id_user','id');
    }
}
