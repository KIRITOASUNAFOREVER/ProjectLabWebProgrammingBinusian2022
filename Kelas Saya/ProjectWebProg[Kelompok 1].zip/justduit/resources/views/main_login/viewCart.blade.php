@extends('layout.layout')


@section('body')

    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                Cart
            </div>
            <div class="card-body">

                @if (!$carts->isEmpty())
                <div>
                    <table class="table text-center table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Image</th>
                                <th scope="col">Name</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total Price</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($carts as $cart)
                                <tr>
                                    <td class="align-middle"><img class="rounded" src="{{ asset('/storage/' . $cart->sepatu->image) }}" style="width: 20vw;height: 30vh;"></td>
                                <td class="align-middle"><a href="{{route('shoesDetail',['shoesId'=>$cart->sepatu->id])}}">{{ $cart->sepatu->name }}</a></td>
                                    <td class="align-middle">{{ $cart->quantity }}</td>
                                    <td class="align-middle">Rp.{{ $cart->sepatu->price * $cart->quantity}}</td>
                                    <td class="align-middle">
                                    <a href="{{route('editCart',['shoesId'=>$cart->sepatu->id])}}" class="btn btn-primary w-100" style="color: aliceblue">Edit</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <a href="{{route('addTransaction')}}" class="btn btn-info w-100" style="color: aliceblue">Checkout</a>
                </div>
                @else
                    Cart is Empty !
                @endif

            </div>
        </div>
    </div>
@endsection
