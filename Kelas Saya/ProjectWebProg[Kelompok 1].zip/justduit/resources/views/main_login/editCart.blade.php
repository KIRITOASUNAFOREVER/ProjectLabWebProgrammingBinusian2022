@extends('layout.layout')

@section('body')

    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                Shoes Detail
            </div>
            <div class="card-body d-flex row">
                <div class="card">
                    <img class="rounded" id="image1" src="{{ asset('/storage/' . $cart->sepatu->image) }}" style="height:40vh;width:30vw">
                </div>
                <div class="col">
                    <div>Name : {{ $cart->sepatu->name }}</div>
                    <div style="min-height: 20vh">Description : <br>{{ $cart->sepatu->description }}</div>
                    <div>Price : Rp.{{ $cart->sepatu->price }}</div>
                    <form action="{{ route('updateCart',['shoesId'=>$cart->sepatu->id]) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label>Quantity :</label>
                        <input type="text" class="form-control  @error('quantity') is-invalid @enderror" name="quantity" value="{{$cart->quantity}}">
                            @error('quantity')
                            <span class="invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                            @enderror
                        </div>
                        <button type="submit" class="btn btn-primary w-100 mb-5">Update</button>
                    </form>
                <a href="{{route('deleteCart',['shoesId'=>$cart->sepatu->id])}}" class="btn btn-danger w-100 mb-5">Delete</a>
                </div>
            </div>
        </div>
    </div>
@endsection
