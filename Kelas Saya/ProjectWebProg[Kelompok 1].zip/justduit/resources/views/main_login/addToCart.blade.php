@extends('layout.layout')
@section('body')

    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                Add to Cart
            </div>
            <div class="card-body d-flex row">
                <div class="card">
                    <img class="rounded" id="image1" src="{{ asset('/storage/' . $shoe->image) }}" style="height:40vh;width:30vw">
                </div>
                <div class="col">
                    <div>Name : {{ $shoe->name }}</div>
                    <div >Description : <br>{{ $shoe->description }}</div>
                    <div style="min-height: 20vh">Price : Rp.{{ $shoe->price }}</div>
                    <form action="{{ route('insertCart',['shoesId'=>$shoe->id]) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @if($error=='')
                        <div class="form-group">
                            <label>Quantity :</label>
                            <input type="text" class="form-control  @error('quantity') is-invalid @enderror" name="quantity">
                            @error('quantity')
                            <span class="invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mb-5">Submit</button>
                        @else
                        <div class="form-group">
                            <label>Quantity :</label>
                            <input type="text" class="form-control  @error('quantity') is-invalid @enderror" name="quantity" disabled>
                            @error('quantity')
                            <span class="invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-secondary w-100" disabled>Submit</button>
                        <div style="color: red">{{$error}}</div>
                        @endif

                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
