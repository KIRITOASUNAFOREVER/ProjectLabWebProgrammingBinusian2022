@extends('layout.layout')
@section('body')
@if(Session::has('success'))
<div class="alert alert-success">
    {{Session::get('success')}}
</div>
@endif
@if ($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif
<div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
    <div class="card w-75">
        <div class="card-header">
            Insert
        </div>
        <div class="card-body">
            <form action="{{ route('insertShoes') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label>Shoes name :</label>
                    <input type="text" class="form-control  @error('name') is-invalid @enderror" name="name">
                    @error('name')
                    <span class="invalid-feedback" role="alert">
                        {{ $message }}
                    </span>
                    @enderror
                </div>
                <div class="form-group">
                    <label>Description :</label>
                    <input type="text" class="form-control  @error('description') is-invalid @enderror"
                        name="description">
                    @error('description')
                    <span class="invalid-feedback" role="alert">
                        {{ $message }}
                    </span>
                    @enderror
                </div>
                <div class="form-group">
                    <label>Price :</label>
                    <div class="input-group mb-2">
                        <div class="input-group-prepend">
                            <div class="input-group-text">Rp.</div>
                        </div>
                        <input type="text" class="form-control  @error('price') is-invalid @enderror" name="price">
                        @error('price')
                        <span class="invalid-feedback" role="alert">
                            {{ $message }}
                        </span>
                        @enderror
                    </div>
                </div>
                <div class="form-group">
                    <label>Image :</label>
                    <input type="file" class="form-control-file  @error('image') is-invalid @enderror" name="image">
                    @error('image')
                    <span class="invalid-feedback" role="alert">
                        {{ $message }}
                    </span>
                    @enderror
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-5">Submit</button>
            </form>
        </div>
    </div>
</div>
@endsection
