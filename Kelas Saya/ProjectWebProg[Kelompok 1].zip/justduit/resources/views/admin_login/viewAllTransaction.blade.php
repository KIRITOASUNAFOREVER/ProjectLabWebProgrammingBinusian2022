@extends('layout.layout')
@section('body')
    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                View All Transaction
            </div>
            <div class="card-body">
                @php
                $x = 0
                @endphp

                @foreach ($transactions as $transaction)
                <div class="card d-flex flex-row" style="background: #548ade">
                    <div class="col">
                        <h5>Created at : {{ $transaction->created_at }}</h5>
                    </div>
                    <h5>Total Price : Rp.{{ $hargaTotal[$x] }},00</h5>
                </div>
                    <div class="card m-4" style="background-color: #a5c3f2">
                        <div class="d-flex flex-row">
                            @foreach ($transaction->transaction_detail as $transaction_detail)
                                <img class="rounded ml-3 mr-3"
                                    src="{{ asset('/storage/' . $transaction_detail->sepatu->image) }}" alt="Card image cap"
                                    width="100px" height="100px">
                            @endforeach
                        </div>



                    </div>
                    @php
                    $x = $x+1;
                    @endphp
                @endforeach
            </div>
        </div>
    </div>
@endsection
