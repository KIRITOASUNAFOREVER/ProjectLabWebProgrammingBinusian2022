@extends('layout.layout')
@section('body')
@if ($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif
<div class="col" style="min-height: 90vh">
    <div class="row ml-auto mr-auto m-5">
        <div class="card bg-light" style="width: 40rem">
            <div class="card-header">
                Shoes Detail
            </div>
            <div class="card-body d-flex row">
                <div class="card ml-3">
                    <img class="rounded " id="image1" src="{{ asset('/storage/' . $shoe->image) }}" style="height:50vh;width:30vw">
                </div>
                <div class="col">
                    <div>Name : {{ $shoe->name }}</div>
                    <div>Description : {{ $shoe->description }}</div>
                    <div>Price : Rp.{{ $shoe->price }}</div>
                </div>
        </div>
    </div>
    <div class="row mr-auto ml-auto m-5">
        <div class="card bg-light" style="width: 40rem">
            <div class="card-header justify-content-center">
                Update shoes
            </div>
            <div class="card-body">
            <form action='{{route('updateSuccess',['shoesId'=>$shoe->id])}}' id="form_update" method="post"
                    enctype="multipart/form-data">
                    @csrf
                    @method('patch')
                    <div id="update">
                        <div class="form-group">
                            <label>ID :</label>
                        <label id="label_id">{{$shoe->id}}</label>
                        </div>
                        <div class="form-group">
                            <label>Shoes name :</label>
                            <input type="text" class="form-control  @error('name') is-invalid @enderror"
                        name="name" id="name" value="{{$shoe->name}}">
                            @error('name')
                            <span class="invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Description :</label>
                            <textarea class="form-control  @error('description') is-invalid @enderror"
                            name="description" id="description">{{$shoe->description}}</textarea>
                            @error('description')
                            <span class="invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Price :</label>
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">Rp.</div>
                                </div>
                                <input type="text" class="form-control  @error('price') is-invalid @enderror"
                                    name="price" id="price" value="{{$shoe->price}}">
                                @error('price')
                                <span class="invalid-feedback" role="alert">
                                    {{ $message }}
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Image :</label>
                            <input type="file" class="form-control-file  @error('image') is-invalid @enderror"
                                name="image">
                            @error('image')
                            <span class="invalid-feedback" role="alert">
                                {{ $message }}
                            </span>
                            @enderror
                        </div>
                    </div>
                    <button type="submit" class="btn btn-info btn-block ">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
