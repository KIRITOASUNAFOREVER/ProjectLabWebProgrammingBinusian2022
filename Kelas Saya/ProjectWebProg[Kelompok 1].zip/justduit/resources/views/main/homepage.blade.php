@extends('layout.layout')

@section('body')
@if(Session::has('Success'))
<div class="alert alert-success">
    {{Session::get('Success')}}
</div>
@endif
    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                View Shoes
            </div>
            @if(!$shoes->isEmpty())
            <div class="card-body d-flex row">
                @foreach ($shoes as $shoe)
                <a href="{{route('shoesDetail',['shoesId'=>$shoe->id])}}" class="col-xl-4 col-l-6 col-12 " style="text-decoration: none;color: black">
                    <div class="card mb-4" style="background-color: #a5c3f2">
                        <img class="card-img-top rounded" src="{{ asset('/storage/' . $shoe->image) }}" alt="Card image cap" width="10vw" height="300vh">
                        <div class="card-body">
                            <div>{{ $shoe->name }}</div>
                            <div>Price : Rp.{{ $shoe->price }}</div>
                        </div>
                    </div>
                </a>
                @endforeach
            </div>
            <div class="mx-auto">
                {{ $shoes->links() }}
            </div>
            @else
            <div class="card-body d-flex row">
                Shoes is empty/not found.
            </div>
            @endif

        </div>
    </div>
@endsection
