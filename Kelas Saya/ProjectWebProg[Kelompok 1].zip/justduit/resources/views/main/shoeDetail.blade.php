@extends('layout.layout')

@section('body')
@if(Session::has('updateSuccess'))
<div class="alert alert-success">
    {{Session::get('updateSuccess')}}
</div>
@endif
    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                Shoes Detail
            </div>
            <div class="card-body d-flex row">
                <div class="card">
                    <img class="rounded" id="image1" src="{{ asset('/storage/' . $shoe->image) }}" style="height:40vh;width:30vw">
                </div>
                <div class="col">
                    <div>Name : {{ $shoe->name }}</div>
                    <div style="min-height: 20vh">Description : <br>{{ $shoe->description }}</div>
                    <div>Price : Rp.{{ $shoe->price }}</div>
                @if (Auth::check())
                    @if (Auth::user()->role == 'User')
                <a href="{{route('addToCart',['shoesId'=>$shoe->id])}}" class="btn btn-info">Add to Cart</a>
                    @endif

                    @if (Auth::user()->role == 'admin')
                <a href="{{route('updateShoes',['shoesId'=>$shoe->id])}}" class="btn btn-info" >Update</a>
                    @endif
                @endif
                </div>
            </div>
        </div>
    </div>
@endsection
