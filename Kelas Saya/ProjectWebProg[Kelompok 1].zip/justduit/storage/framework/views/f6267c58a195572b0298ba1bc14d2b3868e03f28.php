<?php $__env->startSection('navbarUser'); ?>
<li class="nav-item ">
    <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
        style="background-color: #428ef5" href="<?php echo e(route('register')); ?>" disabled>View Cart</a>
</li>
<li class="nav-item ">
    <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
        style="background-color: #428ef5" href="<?php echo e(route('register')); ?>">View Transaction</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('space'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/layout_user.blade.php ENDPATH**/ ?>