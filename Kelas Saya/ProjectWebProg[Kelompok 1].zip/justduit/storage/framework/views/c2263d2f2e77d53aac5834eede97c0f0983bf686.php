<?php $__env->startSection('body'); ?>
<div class="container d-flex justify-content-center align-items-center" style="min-height: 90vh">
    <div class="card w-75">
        <div class="card-header">
          Login
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('main')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-5">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control" name="email" aria-describedby="emailHelp">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" name="password">
                </div>
                <div class="form-group form-check mb-5">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1">Remember me!</label>
                </div>
                <button type="submit" class="btn btn-primary w-100 mb-5">Submit</button>
              </form>
              <div class="error text-center">

                <?php if(Session::has("error")): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get("error")); ?>

                  </div>

                <?php endif; ?>
            </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/login.blade.php ENDPATH**/ ?>