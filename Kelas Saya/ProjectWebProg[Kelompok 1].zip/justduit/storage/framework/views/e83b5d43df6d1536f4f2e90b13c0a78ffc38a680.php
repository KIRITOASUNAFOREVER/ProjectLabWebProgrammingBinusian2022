<?php $__env->startSection('body'); ?>
<?php if(Session::has('Success')): ?>
<div class="alert alert-success">
    <?php echo e(Session::get('Success')); ?>

</div>
<?php endif; ?>
    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                View Shoes
            </div>
            <?php if(!$shoes->isEmpty()): ?>
            <div class="card-body d-flex row">
                <?php $__currentLoopData = $shoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shoe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shoesDetail',['shoesId'=>$shoe->id])); ?>" class="col-xl-4 col-l-6 col-12 " style="text-decoration: none;color: black">
                    <div class="card mb-4" style="background-color: #a5c3f2">
                        <img class="card-img-top rounded" src="<?php echo e(asset('/storage/' . $shoe->image)); ?>" alt="Card image cap" width="10vw" height="300vh">
                        <div class="card-body">
                            <div><?php echo e($shoe->name); ?></div>
                            <div>Price : Rp.<?php echo e($shoe->price); ?></div>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mx-auto">
                <?php echo e($shoes->links()); ?>

            </div>
            <?php else: ?>
            <div class="card-body d-flex row">
                Shoes is empty/not found.
            </div>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/main/homepage.blade.php ENDPATH**/ ?>