<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body style="background-color: aliceblue">
    <div class="container-fluid p-0 m-0">
        <nav class="navbar navbar-expand-lg navbar-light bg-primary" id="navigation"
            style="border-bottom:10px solid #0275d8">
            <a class="navbar-brand pt-0">
                <img  src="<?php echo e(asset('/storage/img/logo.png')); ?>" width="50" height="50" alt="" style="transform: rotate(180deg)">
                <span class="navbar-brand h1 mr-auto">Just Du It!</span>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto" style="min-width: 500px">
                    <li class="nav-item">
                        <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-right border-top  border-left border-dark rounded-top"
                            style="background-color: #428ef5" href="<?php echo e(route('main')); ?>">View All Shoes</a>
                    </li>
                    <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->role == 'User'): ?>
                            <li class="nav-item ">
                                <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
                                    style="background-color: #428ef5" href="<?php echo e(route('viewCart',['userId'=>Auth::user()->id])); ?>">View Cart</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
                                    style="background-color: #428ef5" href="<?php echo e(route('viewTransaction')); ?>">View
                                    Transaction</a>
                            </li>
                        <?php endif; ?>

                        <?php if(Auth::user()->role == 'admin'): ?>
                            <li class="nav-item ">
                                <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
                                    style="background-color: #428ef5" href="<?php echo e(route('viewAddShoes')); ?>">Add Shoes</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
                                    style="background-color: #428ef5" href="<?php echo e(route('viewAllTransaction')); ?>">View All
                                    Transaction</a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
            <?php $__env->startSection('search'); ?>
        <form action="<?php echo e(route('search')); ?>" method="POST" enctype="multipart/form-data" class="form-inline col-xl-5 col-l-5 col-md-3">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control mr-sm-2 col-xl-8 col-l-10 col-md-8" type="search" placeholder="Search"
                    aria-label="Search" name="search">

                <button class="btn btn-info " type="submit">Search</button>
            </form>
            <?php echo $__env->yieldSection(); ?>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item row">
                    <?php if(!Auth::check()): ?>
                        <a class="nav-link ml-4 mr-4" href="<?php echo e(route('login')); ?>">Login</a>
                        <a class="nav-link mr-4 ml-4" href="<?php echo e(route('register')); ?>">Register</a>
                    <?php else: ?>
                        <div class="username mr-5">
                            <label class="justify-content-center">
                                Welcome, <?php echo e(Auth::user()->username); ?>

                            </label>
                <li class="nav-item">
                    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>" role="button">Log out</a>
                </li>
    </div>
    <?php endif; ?>
    </li>
    </ul>

    </nav>
    <div class="body">
        <?php echo $__env->yieldContent('body'); ?>
    </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/layout/layout.blade.php ENDPATH**/ ?>