<?php $__env->startSection('body'); ?>
    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                View All Transaction
            </div>
            <div class="card-body">
                <?php
                $x = 0
                ?>

                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card m-4" style="background-color: #f2e7c9">
                        <span>Created at : <?php echo e($transaction->created_at); ?></span>
                        <span>Total Price : Rp.<?php echo e($hargaTotal[$x]); ?>,00</span>
                        <div class="d-flex flex-row">
                            <?php $__currentLoopData = $transaction->transaction_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img class="rounded ml-3 mr-3"
                                    src="<?php echo e(asset('/storage/' . $transaction_detail->sepatu->image)); ?>" alt="Card image cap"
                                    width="100px" height="100px">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>



                    </div>
                    <?php
                    $x = $x+1;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/admin_login/viewAllTransaction.blade.php ENDPATH**/ ?>