<?php $__env->startSection('body'); ?>

    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                Cart
            </div>
            <div class="card-body">

                <?php if(!$carts->isEmpty()): ?>
                <div>
                    <table class="table text-center table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Image</th>
                                <th scope="col">Name</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total Price</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle"><img class="rounded" src="<?php echo e(asset('/storage/' . $cart->sepatu->image)); ?>" style="width: 20vw;height: 30vh;"></td>
                                <td class="align-middle"><a href="<?php echo e(route('shoesDetail',['shoesId'=>$cart->sepatu->id])); ?>"><?php echo e($cart->sepatu->name); ?></a></td>
                                    <td class="align-middle"><?php echo e($cart->quantity); ?></td>
                                    <td class="align-middle">Rp.<?php echo e($cart->sepatu->price * $cart->quantity); ?></td>
                                    <td class="align-middle">
                                    <a href="<?php echo e(route('editCart',['shoesId'=>$cart->sepatu->id])); ?>" class="btn btn-primary w-100" style="color: aliceblue">Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <a href="<?php echo e(route('addTransaction')); ?>" class="btn btn-info w-100" style="color: aliceblue">Checkout</a>
                </div>
                <?php else: ?>
                    Cart is Empty !
                <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/main_login/viewCart.blade.php ENDPATH**/ ?>