<?php $__env->startSection('navbarUser'); ?>
<li class="nav-item ">
    <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
        style="background-color: #428ef5" href="<?php echo e(route('viewAddShoes',['username'=>$username])); ?>">Add Shoes</a>
</li>
<li class="nav-item ">
    <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-left border-top border-right border-dark rounded-top"
        style="background-color: #428ef5" href="<?php echo e(route('viewAllTransaction',['username'=>$username])); ?>">View All Transaction</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('homepage'); ?>
<li class="nav-item">
    <a class="nav-link h5 mb-0 mt-3 mr-2 ml-2 border-right border-top  border-left border-dark rounded-top"
        style="background-color: #428ef5" href="<?php echo e(route('loginWithAdmin',['username'=>$username])); ?>">View All Shoes</a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('login'); ?>
<div class="username mr-5">
    <label class="justify-content-center">
        Welcome, <?php echo e($username); ?>

    </label>
   <li class="nav-item">
    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>" role="button">Log out</a>
    </li>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/layout/layout_admin.blade.php ENDPATH**/ ?>