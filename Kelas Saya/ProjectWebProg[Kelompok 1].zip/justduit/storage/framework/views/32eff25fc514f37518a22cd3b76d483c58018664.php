<?php $__env->startSection('body'); ?>
<?php if(Session::has('updateSuccess')): ?>
<div class="alert alert-success">
    <?php echo e(Session::get('updateSuccess')); ?>

</div>
<?php endif; ?>
    <div class="d-flex justify-content-center align-items-center " style="min-height: 90vh">
        <div class="card w-75">
            <div class="card-header">
                Shoes Detail
            </div>
            <div class="card-body d-flex row">
                <div class="card">
                    <img class="rounded" id="image1" src="<?php echo e(asset('/storage/' . $shoe->image)); ?>" style="height:40vh;width:30vw">
                </div>
                <div class="col">
                    <div>Name : <?php echo e($shoe->name); ?></div>
                    <div style="min-height: 20vh">Description : <br><?php echo e($shoe->description); ?></div>
                    <div>Price : Rp.<?php echo e($shoe->price); ?></div>
                <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->role == 'User'): ?>
                <a href="<?php echo e(route('addToCart',['shoesId'=>$shoe->id])); ?>" class="btn btn-info">Add to Cart</a>
                    <?php endif; ?>

                    <?php if(Auth::user()->role == 'admin'): ?>
                <a href="<?php echo e(route('updateShoes',['shoesId'=>$shoe->id])); ?>" class="btn btn-info" >Update</a>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\justduit\resources\views/main/shoeDetail.blade.php ENDPATH**/ ?>