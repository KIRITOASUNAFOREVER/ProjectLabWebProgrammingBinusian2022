<?php

use App\user;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class userSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        user::create([
            'username'=> 'test',
            'email'=>'test@test.com',
            'password'=> Hash::make('asdasd'),
            'role'=>'admin'
        ]);
        user::create([
            'username'=> 'asd',
            'email'=>'asd@asd.com',
            'password'=> Hash::make('asdasd'),
            'role'=>'User'
        ]);
    }
}
