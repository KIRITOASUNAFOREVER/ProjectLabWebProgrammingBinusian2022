<?php

use App\sepatu;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class sepatuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    // protected $primarykey='id';
    // protected $table='sepatu';
    // protected $fillable=['name','description','price','image'];
    public function run()
    {
        $image = file_get_contents('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/928392e5-4553-4403-a637-7bccd7ab2f94/air-jordan-4-retro-shoe-bPTQDf.jpg');
        Storage::put('public/img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/928392e5-4553-4403-a637-7bccd7ab2f94/air-jordan-4-retro-shoe-bPTQDf.jpg'),$image,'public');
        sepatu::create([
            'name'=>'Air Jordan 4 Retro',
            'description'=>"One of the most coveted shoe models gets a vintage lift in the Air Jordan 4 Retro. It's got side ankle supports and deluxe upper materials. The shoe delivers a supportive, comfortable fit and the legendary style of the original.",
            'price'=>'3000000',
            'image'=> 'img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/928392e5-4553-4403-a637-7bccd7ab2f94/air-jordan-4-retro-shoe-bPTQDf.jpg')
        ]);
        $image = file_get_contents('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/29c6fed0-daa7-4519-ba76-32dcc4774a7f/kyrie-7-ep-basketball-shoe-8ZrrMn.jpg');
        Storage::put('public/img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/29c6fed0-daa7-4519-ba76-32dcc4774a7f/kyrie-7-ep-basketball-shoe-8ZrrMn.jpg'),$image,'public');
        sepatu::create([
            'name'=>'Kyrie 7 EP',
            'description'=>"Kyrie Irving is a creative force on and off the court. He needs his shoes to keep up with his playmaking, but also sync with his boundary-pushing style and ethos. The Kyrie 7 helps players at all levels take advantage of their quick first step by optimising the shoe's fit, court feel and banking ability. This EP version uses an extra-durable outsole that's ideal for outdoor courts.",
            'price'=>'1900000',
            'image'=> 'img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/29c6fed0-daa7-4519-ba76-32dcc4774a7f/kyrie-7-ep-basketball-shoe-8ZrrMn.jpg')
        ]);
        $image = file_get_contents('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/c51d37b5-2638-4e2a-914c-b8646f3a74bd/kyrie-flytrap-3-older-basketball-shoe-Sckj9R.jpg');
        Storage::put('public/img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/c51d37b5-2638-4e2a-914c-b8646f3a74bd/kyrie-flytrap-3-older-basketball-shoe-Sckj9R.jpg'),$image,'public');
        sepatu::create([
            'name'=>'Kyrie Flytrap 3',
            'description'=>"Run the fast break with the Kyrie Flytrap 3. Combining excellent traction and soft foam cushioning, it's built for players looking to attack in transition. Improved padding around the ankle gives you extra support and comfort.",
            'price'=>'750000',
            'image'=> 'img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/c51d37b5-2638-4e2a-914c-b8646f3a74bd/kyrie-flytrap-3-older-basketball-shoe-Sckj9R.jpg')
        ]);

        $image = file_get_contents('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/cc5ab342-de8d-4feb-accd-0e3f83f41e06/air-zoom-unvrs-flyease-basketball-shoe-PfW4Rr.jpg');
        Storage::put('public/img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/cc5ab342-de8d-4feb-accd-0e3f83f41e06/air-zoom-unvrs-flyease-basketball-shoe-PfW4Rr.jpg'),$image,'public');
        sepatu::create([
            'name'=>'Nike Air Zoom UNVRS FlyEase',
            'description'=>"Built for all basketball players and inspired by Elena Delle Donne, the Nike Air Zoom UNVRS with FlyEase technology gives you a quick and easy way to get into your shoes and onto the court. The heel of the shoe folds down to let you slip in then a strap secures the fit.",
            'price'=>'2400000',
            'image'=> 'img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/cc5ab342-de8d-4feb-accd-0e3f83f41e06/air-zoom-unvrs-flyease-basketball-shoe-PfW4Rr.jpg')
        ]);

        $image = file_get_contents('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/1f036e09-343f-4fad-9c80-d752aa2117a8/lebron-18-basketball-shoe-JNqV61.jpg');
        Storage::put('public/img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/1f036e09-343f-4fad-9c80-d752aa2117a8/lebron-18-basketball-shoe-JNqV61.jpg'),$image,'public');
        sepatu::create([
            'name'=>'LeBron 18',
            'description'=>"When LeBron accelerates down the court, he produces tremendous force. The LeBron 18 is designed to harness his abilities while helping with the stress he puts on his body. Combined cushioning underfoot allows him to use his power for unstoppable bursts of speed.",
            'price'=>'3000000',
            'image'=> 'img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/1f036e09-343f-4fad-9c80-d752aa2117a8/lebron-18-basketball-shoe-JNqV61.jpg')
        ]);

        $image = file_get_contents('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/5b82f2da-744e-40e6-80f5-92358f479952/air-zoom-bb-nxt-basketball-shoe-wRmJMz.jpg');
        Storage::put('public/img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/5b82f2da-744e-40e6-80f5-92358f479952/air-zoom-bb-nxt-basketball-shoe-wRmJMz.jpg'),$image,'public');
        sepatu::create([
            'name'=>'Nike Air Zoom BB NXT',
            'description'=>"Keep your focus on the game in the new Air Zoom BB NXT from Nike Basketball. It's designed to help players feel light, secure and responsive. You get energy back with every step, helping to turn your force into momentum when it matters most.",
            'price'=>'2700000',
            'image'=> 'img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/5b82f2da-744e-40e6-80f5-92358f479952/air-zoom-bb-nxt-basketball-shoe-wRmJMz.jpg')
        ]);
        $image = file_get_contents('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/9bf9a099-727f-458f-a020-9bef06d4ab4a/custom-lebron-soldier-14-by-you.jpg');
        Storage::put('public/img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/9bf9a099-727f-458f-a020-9bef06d4ab4a/custom-lebron-soldier-14-by-you.jpg'),$image,'public');
        sepatu::create([
            'name'=>'LeBron Soldier 14 by You',
            'description'=>"The LeBron Soldier 14 is a glimpse of the future. A retro reflective-design graphic treatment spotlights your flair on the court. Chrome accents, outsole options and personalisation opportunities make it yours.",
            'price'=>'2300000',
            'image'=> 'img/'.basename('https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/9bf9a099-727f-458f-a020-9bef06d4ab4a/custom-lebron-soldier-14-by-you.jpg')
        ]);
    }
}
