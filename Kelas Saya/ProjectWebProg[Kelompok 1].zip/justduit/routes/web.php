<?php

use App\Http\Middleware\logoutState;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::post('/search','sepatuController@search')->name('search');
Route::get('/', 'sepatuController@showMain')->name('main');
Route::get('/{shoesId}/details','sepatuController@showDetail')->name('shoesDetail');
Route::group(['middleware' => 'logoutState'], function () {
    Route::get('/login', 'showController@showLogin')->name('login');
    Route::get('/register', 'showController@showRegister')->name('register');
    Route::post('/register/complete', 'userController@registerUser')->name('registerUser');
    Route::post('/loginSuccess', 'userController@loginUser')->name('loginUser');
});


Route::group(['middleware' => 'loginState'], function () {
    Route::get('/logout', 'userController@logout')->name('logout');
    Route::group(['middleware'=>'loginStateUser'],function(){
        Route::get('/user/viewCart/', 'cartController@showViewCart')->name('viewCart');
        Route::get('/user/addToCart/{shoesId}','cartController@showAddToCart')->name('addToCart');
        Route::post('/user/addToCart/{shoesId}/success','cartController@addToCart')->name('insertCart');
        Route::get('/user/viewCart/{shoesId}/edit','cartController@showEditCart')->name('editCart');
        Route::get('/user/viewCart/{shoesId}/delete','cartController@deleteCart')->name('deleteCart');
        Route::post('/user/viewCart/{shoesId}/complete','cartController@updateCart')->name('updateCart');
        Route::get('/user/addTransaction','transactionController@addTransaction')->name('addTransaction');
        Route::get('/user/viewTransaction','transactionController@viewTransaction')->name('viewTransaction');
    });
    Route::group(['middleware'=>'loginStateAdmin'],function(){
        Route::get('/admin/addShoes', 'userController@showAddShoes')->name('viewAddShoes');
        Route::get('/admin/viewAllTransaction', 'transactionController@ViewAllTransaction')->name('viewAllTransaction');
        Route::get('/admin/updateShoes/{shoesId}', 'sepatuController@updateShoes')->name('updateShoes');
        Route::post('/admin/addSuccess', 'sepatuController@insertShoes')->name('insertShoes');
        Route::patch('/admin/updateShoes/{shoesId}/success','sepatuController@updateSuccess')->name('updateSuccess');
    });

});
