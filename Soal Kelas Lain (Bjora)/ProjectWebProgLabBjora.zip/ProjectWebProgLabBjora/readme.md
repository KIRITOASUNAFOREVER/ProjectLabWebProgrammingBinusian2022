# Step by Step:
1. Open the project folder in your favorite text editor.
2. Open terminal again, be sure to navigate to the project folder (by using `cd` command).
3. type `composer update --verbose --prefer-dist`.
4. Wait.
5. Wait.
6. You can open your XAMPP while waiting, turn on Apache and MySQL.
7. On browser, type `localhost/phpmyadmin` and enter.
8. Create new database "bjora" (without quotes).
9. After the composer update finished, type `php artisan migrate:fresh --seed` in the text editor terminal.
10. Previous command will create you table and all dummy data in the seeder.
11. Finally, `php artisan serve`.

# Naming convention:
1. For controller, please use PascalCase, ex. `HomeController.php`
2. For views, please use underscore to delimit words `_`, ex. `edit_question.blade.php`
3. For model, please use PascalCase like in controller and try to name it only with 1 word, ex. `Question.php`
4. For tables, please use lower case with ending `s`, ex. `questions`
