<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-8">

        <?php if( session('status') ): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="GET" class="mb-3 w-50" action="<?php echo e(route('home_search')); ?>">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search by username or question...">
                <div class="input-group-append">
                    <button class="btn btn-secondary" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
            <div class="card">
                <div class="card-header">Questions</div>

                <?php if( $questions->isEmpty() ): ?>
                    <!-- show this message when no question -->
                    <div class="card-body shadow-sm">
                        <h3 class="text-dark">No Question Found...</h3>
                    </div>
                <?php endif; ?>

                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-body shadow-sm">
                        <div class="position-relative d-flex justify-content-end font-weight-bold text-danger"><?php echo e($question->label->question_label); ?></div>
                        <a style="text-decoration:none;" href="/question/<?php echo e($question->id); ?>">
                            <h3 class="text-dark"><?php echo e($question->question_detail); ?></h3>
                        </a>
                        <div class="created_at text-secondary font-italic">Created at: <?php echo e($question->created_at->diffForHumans()); ?></div>
                        <div class="position-relative d-flex justify-content-end">
                            <div> 
                                <div class="d-inline mr-2">
                                    <a class="text-dark" style="text-decoration:none;" href="/user/<?php echo e($question->user_id); ?>"><?php echo e($question->user->username); ?>

                                    </a>
                                </div>
                                <div class="d-inline">
                                    <a href="/user/<?php echo e($question->user_id); ?>"><img src="<?php echo e(asset('storage/profile_pictures/'.$question->user->profile_picture)); ?>" alt="No Image" srcset="" class="rounded-circle" style="width:50px; height:50px;"></a>
                                </div>
                            </div>
                        </div>
                        <?php if(auth()->guard()->guest()): ?>

                        <?php else: ?>
                            <a class="btn btn-primary" href="/question/<?php echo e($question->id); ?>" role="button">Answer</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="container m-2">
                <div class="row justify-content-center"><?php echo e($questions->links()); ?></div>                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProgLabBjora\resources\views//home.blade.php ENDPATH**/ ?>