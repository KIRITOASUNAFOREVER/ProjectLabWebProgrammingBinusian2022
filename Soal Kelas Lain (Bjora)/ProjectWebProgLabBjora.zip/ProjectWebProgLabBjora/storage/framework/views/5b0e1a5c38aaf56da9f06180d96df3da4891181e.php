<?php $__env->startSection('content'); ?>
<div class="container">
    <button type="button" class="btn btn-outline-secondary ml-5 mb-3"><a href="<?php echo e(route('add_user')); ?>" class="text-dark" style="text-decoration:none;">Add New User</a></button>
    <div class="row justify-content-center">

        <?php if( session('status') ): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body shadow-sm">
                <div class="d-flex justify-content-between">
                <table class="table table-bordered table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Profile Picture</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Role</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Address</th>
                            <th scope="col">Birthday</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row" class="align-middle"><?php echo e($user->id); ?></th>
                                <td class="align-middle text-center">
                                <img src="<?php echo e(asset('storage/profile_pictures/'.$user->profile_picture)); ?>" alt="No Image" srcset="" class="rounded-circle" style="width:60px; height:60px;">
                                </td>
                                <td class="align-middle"><?php echo e($user->username); ?></td>
                                <td class="align-middle"><?php echo e($user->email); ?></td>
                                <td class="align-middle"><?php echo e($user->role); ?></td>
                                <td class="align-middle"><?php echo e($user->gender); ?></td>
                                <td class="align-middle"><?php echo e($user->address); ?></td>
                                <td class="align-middle"><?php echo e($user->birthday); ?></td>
                                <td class="align-middle">
                                    <a href="<?php echo e(route('show_user', $user->id)); ?>" class="d-block badge badge-pill badge-secondary mb-2">View</a>
                                    <a href="<?php echo e(route('admin_edit_user', $user->id)); ?>" class="d-block badge badge-pill badge-success mb-2">Edit</a>
                                    <a href="<?php echo e(route('admin_delete_user', $user->id)); ?>" class="d-block badge badge-pill badge-danger">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProgLabBjora\resources\views/admin/view_users.blade.php ENDPATH**/ ?>