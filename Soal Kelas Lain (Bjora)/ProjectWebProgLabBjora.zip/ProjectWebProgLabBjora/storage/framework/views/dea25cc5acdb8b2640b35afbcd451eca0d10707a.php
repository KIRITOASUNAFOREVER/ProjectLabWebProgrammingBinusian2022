<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

        <?php if( session('status') ): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

            <div class="card">
                <div class="card-body shadow-sm">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex font-weight-bold text-danger justify-content">
                            <?php echo e($question->label->question_label); ?>

                        </div>
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if($question->status == 1): ?>
                                <div class="d-block">
                                    <span class="badge badge-pill badge-success">Open</span>
                                </div>
                            <?php else: ?>
                                <div class="d-block">
                                    <span class="badge badge-pill badge-danger">Close</span>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if( Auth::user()->role == "admin" ): ?>
                                <?php if($question->status == 1): ?>
                                    <form action="<?php echo e(route('admin_change_status', $question->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="text-white badge badge-pill badge-success" name="status" value="0">Open</button>
                                    </form>
                                <?php else: ?>
                                    <form action="<?php echo e(route('admin_change_status', $question->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="text-white align-middle badge badge-pill badge-danger" name="status" value="1">Close</button>
                                    </form>
                                <?php endif; ?>
                            <?php elseif( Auth::id() == $question->user_id ): ?>
                                <?php if($question->status == 1): ?>
                                    <form action="<?php echo e(route('change_status', $question->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="text-white badge badge-pill badge-success" name="status" value="0">Open</button>
                                    </form>
                                <?php else: ?>
                                    <form action="<?php echo e(route('change_status', $question->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="text-white align-middle badge badge-pill badge-danger" name="status" value="1">Close</button>
                                    </form>
                                <?php endif; ?>
                            <?php elseif( Auth::id() != $question->user_id ): ?>
                                <?php if($question->status == 1): ?>
                                    <div class="d-block">
                                        <span class="badge badge-pill badge-success">Open</span>
                                    </div>
                                <?php else: ?>
                                    <div class="d-block">
                                        <span class="badge badge-pill badge-danger">Close</span>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <h2><?php echo e($question->question_detail); ?></h2>
                    <div class="created_at text-secondary font-italic">Asked at <?php echo e($question->created_at->diffForHumans()); ?></div>
                    <div class="position-relative d-flex justify-content-end">
                        <div>
                            <a class="text-dark mr-2" style="text-decoration:none;" href="/user/<?php echo e($question->user_id); ?>"><?php echo e($question->user->username); ?>

                            </a>
                            <div class="d-inline">
                            <a href="/user/<?php echo e($question->user_id); ?>"><img src="<?php echo e(asset('storage/profile_pictures/'.$question->user->profile_picture)); ?>" alt="No Image" srcset="" class="rounded-circle" style="width:50px; height:50px;"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if(auth()->guard()->guest()): ?>
            <!-- guest cannot add answer -->

            <?php else: ?>
                <?php if( Auth::id() == $question->user->id ): ?> 
                <!-- owner cannot answer own questions -->
                    <?php else: ?>
                        <?php if( $question->status == 1): ?>
                        <!-- check status question is open -->
                            <br>
                            <div class="card">
                                <div class="card-header">Add Your Answer</div>
                                <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('add_answer', $question->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <textarea class="form-control d-inline" id="answer_detail" rows="4" name="answer_detail"></textarea>
                                        <div class="d-flex justify-content-end">
                                            <button type="submit" class="btn btn-primary">
                                                Submit Answer
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            <br>

            <div class="card">
                <div class="card-header">Answers</div>

                <?php if( $answer->isEmpty() ): ?>
                    <!-- show this when answer is empty -->
                    <div class="card-body shadow-sm">No Answer Yet...</div>
                <?php endif; ?>

                <?php $__currentLoopData = $answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-body shadow-sm">
                        <div class="d-flex mb-3">
                            <div class="mr-3">
                                <a href="/user/<?php echo e($a->user_id); ?>"><img src="<?php echo e(asset('storage/profile_pictures/'.$a->user->profile_picture)); ?>" alt="No Image" class="rounded-circle" srcset="" style="width:50px; height:50px;"></a>
                            </div>
                            <div class="d-inline">
                                <a class="mt-1 text-dark d-block position-relative" style="text-decoration:none;" href="/user/<?php echo e($a->user_id); ?>"><?php echo e($a->user->username); ?>

                                </a>
                                <div class="answer-date mb-1 text-dark d-block position-relative">Answered at <?php echo e($a->updated_at); ?>

                                </div>
                            </div>
                        </div>

                        <div><?php echo e($a->answer_detail); ?></div>

                        <?php if(auth()->guard()->guest()): ?>
                        <!-- guest see nothing -->

                        <?php else: ?>
                        <!-- other users: owner / admin can edit / delete -->
                            <?php if( Auth::id() == $a->user_id): ?>
                                <div class="d-flex position-relative justify-content-end mt-1">
                                    <a href="<?php echo e(route('edit_answer', $a->id)); ?>" class="badge badge-success mr-1">Edit</a>
                                    <a href="<?php echo e(route('delete_answer', $a->id)); ?>" class="badge badge-danger">Delete</a>
                                </div>
                                <?php elseif( Auth::user()->role == "admin"): ?>
                                <div class="d-flex position-relative justify-content-end mt-1">
                                    <a href="<?php echo e(route('admin_edit_answer', $a->id)); ?>" class="badge badge-success mr-1">Edit</a>
                                    <a href="<?php echo e(route('admin_delete_answer', $a->id)); ?>" class="badge badge-danger">Delete</a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProgLabBjora\resources\views/question/show_question.blade.php ENDPATH**/ ?>