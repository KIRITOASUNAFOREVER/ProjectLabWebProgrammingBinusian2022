<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Bjora')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/register.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/time-stamp.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script>
    <link href="/docs/4.4/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-dark">
            <div class="container">
                <a class="navbar-brand text-danger" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Bjora')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                    <?php if(auth()->guard()->guest()): ?>
                        <!-- not logged in user, display nothing -->
                        <?php else: ?>
                            <!-- check if user admin/member -->
                            <?php if(Auth::user()->role === "admin"): ?>
                                <!-- if user is admin show manage options -->
                                <li class="nav-item pl-2 mt-1">
                                    <div class="dropdown">
                                    <button class="btn btn-outline-light dropdown-toggle btn-sm" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Manage
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                        <button class="dropdown-item" type="button"><a href="<?php echo e(route('view_users')); ?>" class="text-dark" style="text-decoration:none;">User</a></button>
                                        <button class="dropdown-item" type="button"><a href="<?php echo e(route('admin_view_questions')); ?>" class="text-dark" style="text-decoration:none;">Question</a></button>
                                        <button class="dropdown-item" type="button"><a href="<?php echo e(route('view_label')); ?>" class="text-dark" style="text-decoration:none;">Question Label/Topic</a></button>
                                    </div>
                                    </div>
                                </li>
                                <li class="nav-item pl-2">
                                    <a class="nav-link text-white" href="/user/<?php echo e(Auth::id()); ?>/questions"><?php echo e(__('My Question')); ?></a>
                                </li>
                                <li class="nav-item pl-1">
                                    <a class="nav-link text-white" href="/user/<?php echo e(Auth::id()); ?>/inbox"><?php echo e(__('Inbox')); ?></a>
                                </li>
                            <?php else: ?>
                                <!-- user is member, show question and inbox -->
                                <li class="nav-item pl-2">
                                    <a class="nav-link text-white" href="/user/<?php echo e(Auth::id()); ?>/questions"><?php echo e(__('My Question')); ?></a>
                                </li>
                                <li class="nav-item pl-1">
                                    <a class="nav-link text-white" href="/user/<?php echo e(Auth::id()); ?>/inbox"><?php echo e(__('Inbox')); ?></a>
                                </li>
                            <?php endif; ?>
                    <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="/login"><?php echo e(__('Login')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php else: ?>
                            <!-- show add question if user's role is member -->
                            <?php if(Auth::user()->role === "member"): ?>
                                <li class="nav-item border border-primary rounded bg-primary">
                                    <a class="nav-link text-white" href="<?php echo e(route('add_new_question')); ?>"><?php echo e(__('Add Question')); ?></a>
                                </li>
                            <?php endif; ?>
                            <li class="nav-item pl-4 pr-4">
                                <a class="nav-link text-white" href="/user/<?php echo e(Auth::id()); ?>"><?php echo e(__('Profile')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-white" href=""
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="/logout" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="bg-dark shadow-sm pb-2">
            <div class="container">
                <div id="displayDateTime" class="text-white"></div>
            </div>
        </div>
        <div class="content">
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
        <footer class="footer bg-dark pt-2 pb-2">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="text-white d-inline">&copy 2019 Copyright</div>
                    <div class="text-danger d-inline">&nbspBjora.com</div>
                </div>
            </div>
        </footer> 
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ProjectWebProgLabBjora\resources\views/layouts/app.blade.php ENDPATH**/ ?>