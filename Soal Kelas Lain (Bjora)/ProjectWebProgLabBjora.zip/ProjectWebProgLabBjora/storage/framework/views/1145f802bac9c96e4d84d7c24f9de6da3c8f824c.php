<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-8">

        <?php if( session('status') ): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">Profile</div>
                <div class="card-body shadow-sm">
                    <div class="position-relative d-flex justify-content-between">
                        <div class="position-relative d-flex">
                            <div class="d-inline mr-4">
                                <img src="<?php echo e(asset('storage/profile_pictures/'.$user->profile_picture)); ?>" alt="No Image" srcset="" class="rounded-circle" style="width:120px; height:120px;">
                            </div>
                            <div class="d-inline">
                                <h3><?php echo e($user->username); ?></h3>
                                <h6><?php echo e($user->email); ?></h6>
                                <h6><?php echo e($user->address); ?></h6>
                                <h6><?php echo e($user->birthday); ?></h6>
                            </div>
                        </div>

                        <!-- validasi edit profile; tampilkan bila user sekarang adalah auth -->
                        <?php if(Auth::id() == $user->id): ?>
                            <div class="d-inline">
                                <a class="btn btn-primary justify-content-end" href="/user/<?php echo e($user->id); ?>/update" role="button">Edit Profile</a>
                            </div>
                        <?php elseif( Auth::user()->role == "admin" ): ?>
                        <div class="d-inline">
                            <div class="d-block mb-1">
                                <a class="btn btn-primary justify-content-end" href="/admin/<?php echo e($user->id); ?>/edit" role="button">Edit <?php echo e($user->username); ?>'s Profile</a>
                            </div>
                            <div class="d-block mb-1">
                                <a class="btn btn-success justify-content-end" href="<?php echo e(route('admin_view_user_questions', $user->id)); ?>" role="button"><?php echo e($user->username); ?>'s Questions</a>
                            </div>
                            <div class="d-block">
                                <a class="btn btn-secondary justify-content-end" href="<?php echo e(route('admin_view_inbox', $user->id)); ?>" role="button"><?php echo e($user->username); ?>'s Inbox</a>
                            </div>
                        </div>
                            
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <br>

    <!-- validasi message; tampilkan bila user sekarang bukan auth -->
    <?php if(auth()->guard()->guest()): ?>

    <?php else: ?>
        <?php if( Auth::id() == $user->id ): ?>

            <?php else: ?>
            <div class="row justify-content-center">
                <div class="col-md-5">
                <div class="card">
                    <div class="card-header">Send Message to <?php echo e($user->username); ?></div>
                        <div class="card-body shadow-sm d-inline">
                            <form method="POST" action="<?php echo e(route('send_message', $user->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <textarea class="form-control d-inline" id="message_detail" rows="4" name="message_detail"></textarea>
                                <div class="d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Send Message')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProgLabBjora\resources\views/user/show_user.blade.php ENDPATH**/ ?>