<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-8">

        <?php if( session('status') ): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="GET" class="mb-3 w-50" action="<?php echo e(route('user_question_search', $user)); ?>">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search by question...">
                <div class="input-group-append">
                    <button class="btn btn-secondary" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
            <table class="table table-bordered table-hover">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Topic</th>
                    <th scope="col">Owner</th>
                    <th scope="col">Question Detail</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($question->label->question_label); ?></td>
                        <td class="align-middle"><?php echo e($question->user->username); ?></td>
                        <td class="align-middle"><?php echo e($question->question_detail); ?></td>
                        <td class="align-middle">
                            <?php if( Auth::user()->role == "admin" ): ?>
                                <?php if($question->status == 1): ?>
                                    <form action="<?php echo e(route('admin_change_status', $question->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="btn btn-sm btn-success" name="status" value="0">Open</button>
                                    </form>
                                    <?php else: ?>
                                    <form action="<?php echo e(route('admin_change_status', $question->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="btn btn-sm btn-danger" name="status" value="1">Close</button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($question->status == 1): ?>
                                    <form action="<?php echo e(route('change_status', $question->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="btn btn-sm btn-success" name="status" value="0">Open</button>
                                    </form>
                                    <?php else: ?>
                                    <form action="<?php echo e(route('change_status', $question->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <button type="sumbit" class="btn btn-sm btn-danger" name="status" value="1">Close</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="align-middle">
                            <?php if( Auth::id() == $question->user_id ): ?>
                                <div class="d-flex">
                                    <a href="<?php echo e(route('show_question', $question->id)); ?>" class="badge badge-secondary d-inline mr-1">View</a>
                                    <a href="<?php echo e(route('edit_question', $question->id)); ?>" class="badge badge-success d-inline mr-1">Edit</a>
                                    <a href="<?php echo e(route('delete_question', $question->id)); ?>" class="badge badge-danger d-inline">Delete</a>
                                </div>
                            <?php elseif( Auth::user()->role == "admin" ): ?>
                                <div class="d-flex">
                                    <a href="<?php echo e(route('show_question', $question->id)); ?>" class="badge badge-secondary d-inline mr-1">View</a>
                                    <a href="<?php echo e(route('admin_edit_question', $question->id)); ?>" class="badge badge-success d-inline mr-1">Edit</a>
                                    <a href="<?php echo e(route('admin_delete_question', $question->id)); ?>" class="badge badge-danger d-inline">Delete</a>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            <div class="container m-2">
                <div class="row justify-content-center"><?php echo e($questions->links()); ?></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProgLabBjora\resources\views/user/view_user_questions.blade.php ENDPATH**/ ?>