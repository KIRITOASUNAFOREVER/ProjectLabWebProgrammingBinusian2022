<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('img/evan-dennis-i--IN3cvEjg-unsplash.jpg')); ?>" alt="" srcset="" class="img-fluid">
    <h1 style="left:32%;top:65%;position:absolute;font-size:80px">
        <p class="text-white bg-dark font-italic">Are You Lost?</p>
    </h1>
    <h5 style="left:32%;top:80%;position:absolute;">
        <p class="text-white bg-dark font-italic">Maybe you should ask more questions...</p>
    </h5>
    <a href="/" class="btn btn-outline-light btn-lg " role="button" aria-disabled="true" style="left:42%;top:86%;position:absolute">Lead Me to the Right Way</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectWebProgLabBjora\resources\views/error_page.blade.php ENDPATH**/ ?>